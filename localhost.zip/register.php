<?php include('server.php') ?>
<!DOCTYPE html>
<html>
<head>
  <title>Registration system PHP and MySQL</title>
  <link rel="stylesheet" type="text/css" href="style1.css">
</head>
<body>



  <form method="post" action="register.php">
  	<?php include('errors.php'); ?>
      <div class="header">
    <h2>Регистрация</h2>
  </div>
<br>
  	<div class="input-group">
  	  <label>Имя</label>
  	  <input type="text" name="username" value="<?php echo $username; ?>">
  	</div>
  	<div class="input-group">
  	  <label>Email</label>
  	  <input type="email" name="email" value="<?php echo $email; ?>">
  	</div>
  	<div class="input-group">
  	  <label>Пароль</label>
  	  <input type="password" name="password_1">
      <i class="uil uil-eye-slash showHidePw"></i>
  	</div>
  	<div class="input-group">
  	  <label>Подтвердите пароль</label>
  	  <input type="password" name="password_2">
  	</div>
  	<div class="input-group">
  	  <button type="submit" class="btn" name="reg_user">Зарегестрироваться</button>
  	</div>
    <br>
  	<p>
  		Уже есть аккаунт? <a href="login.php">Войти</a>
  	</p>
  </form>
  <script type="text/javascript">
    const modalBtns = document.querySelectorAll('._modal-open');
const modals = document.querySelectorAll('._modal');

const body = document.body;

function openModal(elem) {
  elem.classList.add('_active');
  body.classList.add('_locked')
}

function closeModal(e) {
  if (e.target.classList.contains('modal-close') || e.target.closest('.modal-close') || e.target.classList.contains('modal-bg')) {
    e.target.closest('._modal').classList.remove('_active');
    body.classList.remove('_locked')
  }
}

modalBtns.forEach(btn => {
  btn.addEventListener('click', (e) => {
    let data = e.target.dataset.modalOpen;

    modals.forEach(modal => {
      if (modal.dataset.modal == data || modal.dataset.modal == e.target.closest('._modal-open').dataset.modalOpen) {
        openModal(modal)
      }
    })
  })
})

modals.forEach(modal => {
  modal.addEventListener('click', e => closeModal(e))
})

window.addEventListener('keydown', e => {
  modals.forEach(modal => {
    if (e.key === "Escape" && modal.classList.contains('_active')) {
      modal.classList.remove('_active');
      body.classList.remove('_locked');
    }
  })
})
  </script>
</body>
</html>