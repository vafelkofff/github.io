<?

$link = mysqli_connect('localhost', 'mysql', 'mysql', 'registration')
or die ('Error' . mysqli_error($linl));

?>